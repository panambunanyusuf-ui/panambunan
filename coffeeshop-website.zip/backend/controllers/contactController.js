const fs = require('fs');
const path = require('path');

const contactFile = path.join(__dirname, '../../data/contacts.json');
const newsletterFile = path.join(__dirname, '../../data/newsletter.json');

// Load data from JSON file
function loadContactsData() {
    try {
        const data = fs.readFileSync(contactFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

function loadNewsletterData() {
    try {
        const data = fs.readFileSync(newsletterFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

// Save data to JSON file
function saveContactsData(data) {
    fs.writeFileSync(contactFile, JSON.stringify(data, null, 2));
}

function saveNewsletterData(data) {
    fs.writeFileSync(newsletterFile, JSON.stringify(data, null, 2));
}

// Submit contact form
exports.submitContact = (req, res) => {
    try {
        const { name, email, phone, subject, message } = req.body;
        
        if (!name || !email || !message) {
            return res.status(400).json({
                success: false,
                message: 'Name, email, and message are required'
            });
        }
        
        const contacts = loadContactsData();
        const newContact = {
            id: Date.now().toString(),
            name,
            email,
            phone,
            subject,
            message,
            status: 'unread',
            createdAt: new Date()
        };
        
        contacts.push(newContact);
        saveContactsData(contacts);
        
        res.status(201).json({
            success: true,
            message: 'Contact message saved successfully',
            data: newContact
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Get all contacts
exports.getAllContacts = (req, res) => {
    try {
        const contacts = loadContactsData();
        res.json({
            success: true,
            data: contacts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Newsletter subscription
exports.subscribeNewsletter = (req, res) => {
    try {
        const { email } = req.body;
        
        if (!email) {
            return res.status(400).json({
                success: false,
                message: 'Email is required'
            });
        }
        
        const newsletter = loadNewsletterData();
        
        // Check if already subscribed
        if (newsletter.find(n => n.email === email)) {
            return res.status(400).json({
                success: false,
                message: 'Email already subscribed'
            });
        }
        
        const newSubscriber = {
            id: Date.now().toString(),
            email,
            subscribedAt: new Date()
        };
        
        newsletter.push(newSubscriber);
        saveNewsletterData(newsletter);
        
        res.status(201).json({
            success: true,
            message: 'Successfully subscribed to newsletter',
            data: newSubscriber
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};