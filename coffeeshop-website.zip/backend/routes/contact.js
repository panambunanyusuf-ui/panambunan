const express = require('express');
const router = express.Router();
const contactController = require('../controllers/contactController');

// Submit contact form
router.post('/', contactController.submitContact);

// Get all contact messages
router.get('/', contactController.getAllContacts);

// Newsletter subscription
router.post('/newsletter', contactController.subscribeNewsletter);

module.exports = router;