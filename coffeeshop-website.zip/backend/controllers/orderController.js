const fs = require('fs');
const path = require('path');

const ordersFile = path.join(__dirname, '../../data/orders.json');

// Load data from JSON file
function loadOrdersData() {
    try {
        const data = fs.readFileSync(ordersFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

// Save data to JSON file
function saveOrdersData(data) {
    fs.writeFileSync(ordersFile, JSON.stringify(data, null, 2));
}

// Get all orders
exports.getAllOrders = (req, res) => {
    try {
        const orders = loadOrdersData();
        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Get order by ID
exports.getOrderById = (req, res) => {
    try {
        const orders = loadOrdersData();
        const order = orders.find(o => o.id === req.params.id);
        
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }
        
        res.json({
            success: true,
            data: order
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Create new order
exports.createOrder = (req, res) => {
    try {
        const { customerName, customerEmail, items, totalAmount, notes } = req.body;
        
        if (!customerName || !customerEmail || !items || items.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Customer name, email, and items are required'
            });
        }
        
        const orders = loadOrdersData();
        const newOrder = {
            id: Date.now().toString(),
            customerName,
            customerEmail,
            items,
            totalAmount,
            notes,
            status: 'pending',
            createdAt: new Date(),
            updatedAt: new Date()
        };
        
        orders.push(newOrder);
        saveOrdersData(orders);
        
        res.status(201).json({
            success: true,
            data: newOrder
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Update order
exports.updateOrder = (req, res) => {
    try {
        const orders = loadOrdersData();
        const orderIndex = orders.findIndex(o => o.id === req.params.id);
        
        if (orderIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }
        
        orders[orderIndex] = {
            ...orders[orderIndex],
            ...req.body,
            id: orders[orderIndex].id,
            updatedAt: new Date()
        };
        
        saveOrdersData(orders);
        
        res.json({
            success: true,
            data: orders[orderIndex]
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Delete order
exports.deleteOrder = (req, res) => {
    try {
        let orders = loadOrdersData();
        const orderIndex = orders.findIndex(o => o.id === req.params.id);
        
        if (orderIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }
        
        const deletedOrder = orders.splice(orderIndex, 1);
        saveOrdersData(orders);
        
        res.json({
            success: true,
            data: deletedOrder[0]
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};