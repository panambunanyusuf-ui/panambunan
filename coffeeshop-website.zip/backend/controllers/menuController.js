const fs = require('fs');
const path = require('path');

const dataFile = path.join(__dirname, '../../data/menu.json');

// Load data from JSON file
function loadMenuData() {
    try {
        const data = fs.readFileSync(dataFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

// Save data to JSON file
function saveMenuData(data) {
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
}

// Get all menu items
exports.getAllMenu = (req, res) => {
    try {
        const limit = req.query.limit ? parseInt(req.query.limit) : null;
        let menu = loadMenuData();
        
        if (limit) {
            menu = menu.slice(0, limit);
        }
        
        res.json({
            success: true,
            data: menu
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Get menu item by ID
exports.getMenuById = (req, res) => {
    try {
        const menu = loadMenuData();
        const item = menu.find(m => m.id === parseInt(req.params.id));
        
        if (!item) {
            return res.status(404).json({
                success: false,
                message: 'Menu item not found'
            });
        }
        
        res.json({
            success: true,
            data: item
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Create menu item
exports.createMenu = (req, res) => {
    try {
        const { name, category, price, description, image } = req.body;
        
        if (!name || !category || !price) {
            return res.status(400).json({
                success: false,
                message: 'Name, category, and price are required'
            });
        }
        
        const menu = loadMenuData();
        const newItem = {
            id: menu.length > 0 ? Math.max(...menu.map(m => m.id)) + 1 : 1,
            name,
            category,
            price,
            description,
            image,
            createdAt: new Date()
        };
        
        menu.push(newItem);
        saveMenuData(menu);
        
        res.status(201).json({
            success: true,
            data: newItem
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Update menu item
exports.updateMenu = (req, res) => {
    try {
        const menu = loadMenuData();
        const itemIndex = menu.findIndex(m => m.id === parseInt(req.params.id));
        
        if (itemIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Menu item not found'
            });
        }
        
        menu[itemIndex] = {
            ...menu[itemIndex],
            ...req.body,
            id: menu[itemIndex].id
        };
        
        saveMenuData(menu);
        
        res.json({
            success: true,
            data: menu[itemIndex]
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

// Delete menu item
exports.deleteMenu = (req, res) => {
    try {
        let menu = loadMenuData();
        const itemIndex = menu.findIndex(m => m.id === parseInt(req.params.id));
        
        if (itemIndex === -1) {
            return res.status(404).json({
                success: false,
                message: 'Menu item not found'
            });
        }
        
        const deletedItem = menu.splice(itemIndex, 1);
        saveMenuData(menu);
        
        res.json({
            success: true,
            data: deletedItem[0]
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};